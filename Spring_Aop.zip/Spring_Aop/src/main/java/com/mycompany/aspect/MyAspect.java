package com.mycompany.aspect;

public class MyAspect {

}
