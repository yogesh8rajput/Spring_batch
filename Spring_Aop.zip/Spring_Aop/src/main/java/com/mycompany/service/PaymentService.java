package com.mycompany.service;

public interface PaymentService {

	public void makePayment();
}
