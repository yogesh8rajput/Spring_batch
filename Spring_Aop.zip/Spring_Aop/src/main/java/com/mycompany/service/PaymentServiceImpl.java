package com.mycompany.service;

public class PaymentServiceImpl implements PaymentService {

	@Override
	public void makePayment() {
		System.out.println("Payment Debited");
		System.out.println("Payment Credited");
		
	}

}
